// Chrome-specific
function getAppVersion() {
    return chrome.app.getDetails().version;
}

function getRulesUrl() {
    return "https://cr-input.superzoom.net/zooming";
}