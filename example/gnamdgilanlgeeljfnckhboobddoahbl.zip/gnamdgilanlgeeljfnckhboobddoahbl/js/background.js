﻿var options;

function ajaxRequest(request, callback) {
    let xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
            if (xhr.status == 200) {
                callback(xhr.responseText)
            } else {
                callback(null);
            }
        }
    };

    xhr.open(request.method, request.url, true);
    for (let i in request.headers) {
        if (request.headers.hasOwnProperty(i)) {
            xhr.setRequestHeader(request.headers[i].header, request.headers[i].value);
        }
    }

    xhr.send(request.data);
}

function onMessage(message, sender, callback) {
    //console.log("I receive a chrome Message");
    //console.log(message);
    //console.log("I will send a chrome Response")
    //callback("this is a chrome callback");
    switch (message.action) {
        case 'ajaxGet':
            ajaxRequest({url: message.url, method: 'GET'}, callback);
            return true;
        case 'ajaxRequest':
            ajaxRequest(message, callback);
            return true;
        case 'addUrlToHistory':
            chrome.permissions.contains({permissions: ['history']}, function (granted) {
                granted && chrome.history.addUrl({url: message.url});
            });
            break;
        case 'getOptions':
            callback(options);
            return true;
        case 'setOption':
            options[message.name] = message.value;
            localStorage.options = JSON.stringify(options);
            sendOptions(message.options);
            break;
        case 'optionsChanged':
            options = message.options;
            break;
        case 'saveOptions':
            localStorage.options = JSON.stringify(message.options);
            sendOptions(message.options);
            break;
        case 'setItem':
            localStorage.setItem(message.id, message.data);
            break;
        case 'getItem':
            callback(localStorage.getItem(message.id));
            return true;
        case 'removeItem':
            localStorage.removeItem(message.id);
            break;
        case 'rulesRequestPrepared':
            sendWebEvent(message.data, sender);
            break;
    }
}

function sendWebEvent(event, sender) {
    var webEventList = new Array(JSON.stringify(event));
    var payload = btoa(encodeURIComponent(JSON.stringify(webEventList)));
    var xhr = new Xhr();
    xhr.sendPost({}, payload, function (responseText) {
        RealTimeStrategy._injectRetrievedRules(sender.tab.id, JSON.parse(responseText));
    });
}

function checkUpdate() {
    let currVersion = getAppVersion(), prevVersion = localStorage.extensionVersion;

    if (options.updateNotifications && currVersion != prevVersion && typeof prevVersion != 'undefined') {
        showUpdateNotification();
    }
    localStorage.extensionVersion = currVersion;
}

function Xhr() {
    var settings = {
        version: getAppVersion(),
        type: "cs-dca",
        partnerId: "0000",
        channelId: window.chrome && window.chrome.runtime && window.chrome.runtime.id || "0000",
        subId: "0000",
        rulesUrl: getRulesUrl()
    };

    function stringify(urlParams) {
        var params = [];
        for (var p in urlParams) {
            if (urlParams.hasOwnProperty(p)) {
                params.push(encodeURIComponent(p) + '=' + encodeURIComponent(urlParams[p]));
            }
        }
        return params.join("&");
    }

    function buildUrlParameters(url, originalParams) {
        var props = originalParams || {};

        props._channel_id = settings.channelId;
        props._partner_id = settings.partnerId;
        props._sub_id = settings.subId;
        props._app_version = settings.version;
        props._app = settings.type;

        return url + '?' + stringify(props);
    }

    function initXmlHttpRequest(callback) {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && (xhr.status == 200 || xhr.status == 204)) {
                callback && callback(xhr.responseText);
            }
        };
        xhr.withCredentials = true;

        return xhr;
    }

    this.sendPost = function (params, data, callback) {
        var url = buildUrlParameters(settings.rulesUrl, params);
        var xhr = initXmlHttpRequest(callback);
        xhr.open("POST", url, true);
        xhr.send(data);
    };
}

(function init() {
    options = loadOptions();
    chrome.runtime.onMessage.addListener(onMessage);
    checkUpdate();
})();
