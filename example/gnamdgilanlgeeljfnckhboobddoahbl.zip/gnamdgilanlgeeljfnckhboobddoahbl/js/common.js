function loadOptions() {
    let options;
    if (localStorage.options == null) {
        localStorage.options = '{}';
    }
    options = JSON.parse(localStorage.options);

    options.realTimeZoomingRulesMode = options.hasOwnProperty('realTimeZoomingRulesMode') ? options.realTimeZoomingRulesMode : true;
    options.passiveZoomingRulesMode = options.hasOwnProperty('passiveZoomingRulesMode') ? options.passiveZoomingRulesMode : false;
    options.zoomFactor = options.hasOwnProperty('zoomFactor') ? options.zoomFactor : 1;
    options.pageActionEnabled = options.hasOwnProperty('pageActionEnabled') ? options.pageActionEnabled : true;
    options.showCaptions = options.hasOwnProperty('showCaptions') ? options.showCaptions : true;
    options.showHighRes = options.hasOwnProperty('showHighRes') ? options.showHighRes : true;
    options.galleriesMouseWheel = options.hasOwnProperty('galleriesMouseWheel') ? options.galleriesMouseWheel : true;
    options.addToHistory = options.hasOwnProperty('addToHistory') ? options.addToHistory : false;
    options.alwaysPreload = options.hasOwnProperty('alwaysPreload') ? options.alwaysPreload : false;
    options.displayDelay = options.hasOwnProperty('displayDelay') ? options.displayDelay : 100;
    options.fadeDuration = options.hasOwnProperty('fadeDuration') ? options.fadeDuration : 200;
    options.picturesOpacity = options.hasOwnProperty('picturesOpacity') ? options.picturesOpacity : 1;
    options.showWhileLoading = options.hasOwnProperty('showWhileLoading') ? options.showWhileLoading : true;
    options.mouseUnderlap = options.hasOwnProperty('mouseUnderlap') ? options.mouseUnderlap : true;
    options.updateNotifications = options.hasOwnProperty('updateNotifications') ? options.updateNotifications : true;
    options.filterNSFW = options.hasOwnProperty('filterNSFW') ? options.filterNSFW : false;
    options.enableGalleries = options.hasOwnProperty('enableGalleries') ? options.enableGalleries : true;
    options.disabledPlugins = options.hasOwnProperty('disabledPlugins') ? options.disabledPlugins : [];

    localStorage.options = JSON.stringify(options);

    return options;
}

function sendOptions(options) {
    let request = {action: 'optionsChanged', 'options': options};

    chrome.windows.getAll(null, function (windows) {
        for (let i = 0; i < windows.length; i++) {
            chrome.tabs.getAllInWindow(windows[i].id, function (tabs) {
                for (let j = 0; j < tabs.length; j++) {
                    chrome.tabs.sendMessage(tabs[j].id, request);
                }
            });
        }
    });

    chrome.runtime.sendMessage(request);
}

function showUpdateNotification() {
    if (chrome.notifications) {
        let options = {
            type: 'list',
            title: chrome.i18n.getMessage('extUpdated'),
            message: '',
            iconUrl: '/images/icon32.png',
            items: [
                {title: "Ambient light for images", message: ""}
            ]
        };
        chrome.notifications.create(chrome.i18n.getMessage('extName'), options, function (id) {
        });
    }
    return false;
}

function i18n() {
    $('[data-i18n]').each(function (index, element) {
        let elem = $(element);
        elem.text(chrome.i18n.getMessage(elem.attr('data-i18n')));
    });
    $('[data-i18n-placeholder]').each(function (index, element) {
        let elem = $(element);
        elem.attr('placeholder', chrome.i18n.getMessage(elem.attr('data-i18n-placeholder')));
    });
    $('[data-i18n-tooltip]').each(function (index, element) {
        let elem = $(element);
        elem.attr('data-tooltip', chrome.i18n.getMessage(elem.attr('data-i18n-tooltip')));
    });
}
