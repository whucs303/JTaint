var options, superZoomPlugins = superZoomPlugins || [];

function getMilliseconds(ctrl) {
    let value = parseFloat(ctrl.val());
    value = isNaN(value) ? 0 : value * 1000;
    ctrl.val(value / 1000);
    return value;
}

function saveOptions() {
    options.realTimeZoomingRulesMode = $("#realTimeZoomingRulesMode")[0].checked;
    options.passiveZoomingRulesMode = $("#passiveZoomingRulesMode")[0].checked;
    options.zoomFactor = $('#txtZoomFactor')[0].value;
    options.mouseUnderlap = $('#chkMouseUnderlap')[0].checked;
    options.pageActionEnabled = $('#chkPageActionEnabled')[0].checked;
    options.showCaptions = $('#chkShowCaptions')[0].checked;
    options.showWhileLoading = $('#chkShowWhileLoading')[0].checked;
    options.showHighRes = $('#chkShowHighRes')[0].checked;
    options.galleriesMouseWheel = $('#chkGalleriesMouseWheel')[0].checked;
    options.displayDelay = getMilliseconds($('#txtDisplayDelay'));
    options.fadeDuration = getMilliseconds($('#txtFadeDuration'));

    options.disabledPlugins = [];
    $('.chkPlugin').each(function () {
        let self = $(this);
        if (!self.is(':checked')) {
            options.disabledPlugins.push(self.attr('id').substr('chkPlugin'.length));
        }
    });

    options.updateNotifications = $('#chkUpdateNotifications')[0].checked;
    options.addToHistory = $('#chkAddToHistory')[0].checked;
    options.filterNSFW = $('#chkFilterNSFW')[0].checked;
    options.alwaysPreload = $('#chkAlwaysPreload')[0].checked;
    options.enableGalleries = $('#chkEnableGalleries')[0].checked;
    options.picturesOpacity = $('#txtPicturesOpacity')[0].value / 100;

    localStorage.options = JSON.stringify(options);
    sendOptions(options);
    restoreOptions();
    $('#messages').clearQueue().animate({opacity: 1}, 500).delay(5000).animate({opacity: 0}, 500);
    return false;
}

// Restores options from localStorage.
function restoreOptions() {
    options = loadOptions();

    $("#realTimeZoomingRulesMode")[0].checked = options.realTimeZoomingRulesMode;
    $("#passiveZoomingRulesMode")[0].checked = options.passiveZoomingRulesMode;
    $('#txtZoomFactor')[0].value = options.zoomFactor;
    $('#chkMouseUnderlap')[0].checked = options.mouseUnderlap;
    $('#chkPageActionEnabled')[0].checked = options.pageActionEnabled;
    $('#chkShowCaptions')[0].checked = options.showCaptions;
    $('#chkShowWhileLoading')[0].checked = options.showWhileLoading;
    $('#chkShowHighRes')[0].checked = options.showHighRes;
    $('#chkGalleriesMouseWheel')[0].checked = options.galleriesMouseWheel;
    $('#txtDisplayDelay').val((options.displayDelay || 0) / 1000);
    $('#txtFadeDuration').val((options.fadeDuration || 0) / 1000);

    $('#chkUpdateNotifications')[0].checked = options.updateNotifications;
    $('#chkAddToHistory')[0].checked = options.addToHistory;
    $('#chkFilterNSFW')[0].checked = options.filterNSFW;

    $('#chkAlwaysPreload')[0].checked = options.alwaysPreload;
    $('#chkEnableGalleries')[0].checked = options.enableGalleries;
    $('#txtPicturesOpacity').val(options.picturesOpacity * 100);

    $('input:checked').trigger('gumby.check');
    return false;
}

function chkAddToHistoryModeOnChange() {
    if ($('#chkAddToHistory')[0].checked) {
        chrome.permissions.contains({permissions: ['history']}, function (granted) {
            if (!granted) {
                chrome.permissions.request({permissions: ['history']}, function (granted) {
                    if (!granted) {
                        $("#chkAddToHistory").trigger('gumby.uncheck');
                    }
                });
            }
        });
    }
}

function percentageOnChange() {
    let value = parseInt(this.value);

    if (isNaN(value) || value > 100) {
        value = 100;
    }
    if (value < 1) {
        value = 1;
    }

    this.value = value;
}

function onMessage(message, sender, callback) {
    switch (message.action) {
        case 'optionsChanged':
            restoreOptions();
            break;
    }
}

function populatePluginsTable() {
    $.unique(plugins_list).forEach(function (plugin) {
        let chkName = 'chkPlugin' + plugin.replace(/[^\w]/g, '').toLowerCase();
        $('<div class="field"><label class="checkbox" for="' + chkName + '"><input type="checkbox" id="' + chkName + '" class="chkPlugin"><span></span>&nbsp;<div style="display:inline">' + plugin + '</div></label></div>').appendTo('#tblPlugins');
        $('#' + chkName)[0].checked = !options.disabledPlugins.includes(chkName.substr('chkPlugin'.length));
    });
    Gumby.initialize('checkbox');
}

$(function () {
    i18n();
    $("#version").text(chrome.i18n.getMessage("optFooterVersionCopyright", getAppVersion()));

    $('#btnSave').click(saveOptions);
    $('#btnReset').click(restoreOptions);
    $('#chkAddToHistory').parent().on('gumby.onChange', chkAddToHistoryModeOnChange);
    $('#txtZoomFactor').change(percentageOnChange);
    $('#txtPicturesOpacity').change(percentageOnChange);
    $('#aShowUpdateNotification').click(showUpdateNotification);

    restoreOptions();
    populatePluginsTable();

    chrome.runtime.onMessage.addListener(onMessage);
});
