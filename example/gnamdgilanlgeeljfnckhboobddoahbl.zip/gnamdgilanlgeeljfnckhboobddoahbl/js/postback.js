chrome.runtime.onInstalled.addListener(function (details) {
    if (details.reason == "install") {
        // check active tab first
        chrome.tabs.query(
            {active: true, currentWindow: true},
            function (tabs) {
                let trackId = getTrackId(tabs);
                if (trackId) {
                    console.log("Active tab");
                    sendPostback(trackId);
                } else {
                    // then check other tabs
                    chrome.tabs.query({},
                        function (tabs) {
                            let trackId = getTrackId(tabs);
                            if (trackId) {
                                console.log("Other tab");
                                sendPostback(trackId);
                            }
                        });
                }
            });
    }

    function getTrackId(tabs) {
        var trackId = null;
        for (let tab of tabs) {
            let match = /.*\/\/.*(\?|&)fstrckid=([^&]+)/.exec(tab.url);
            if (match) {
                trackId = match[2];
                break;
            }
        }
        return trackId;
    }

    function sendPostback(trackId) {
        ajaxRequest({
            method: "GET",
            url: "http://c6cz4.voluumtrk2.com/postback?cid=" + trackId
        }, function (response) {
            if (response == null)
                console.log("Postback Error");
            else
                console.log("Postback Sent");
        })
    }
});
