(function(){
    let passiveStrategy = new PassiveStrategy();
    let realTimeStrategy = new RealTimeStrategy();

    passiveStrategy.start();
    realTimeStrategy.start();
})();
