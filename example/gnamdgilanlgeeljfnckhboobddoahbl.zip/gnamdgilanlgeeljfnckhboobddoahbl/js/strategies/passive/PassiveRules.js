const passivePluginRules = [
    {
        "js": [
            "js/libs/jquery-2.1.1.min.js",
            "js/tools.js",
            "js/plugins.js",
            "passive_plugins/default.js"
        ],
        "matches": [
            /.*/
        ],
        "all_frames": true
    }
];
