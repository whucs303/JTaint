class PassiveStrategy {

    constructor() {
    }

    static _matches(url, regexps) {
        for (let regexp of regexps) {
            if (url.match(regexp)) {
                return true;
            }
        }
        return false;
    }

    static _getDetails(rule, file) {
        return {file: file, allFrames: rule.all_frames, runAt: rule.run_at || 'document_idle'};
    }

    static _isSuitablePassiveInjection(tab) {
        return options.passiveZoomingRulesMode && tab.url.indexOf('chrome://') != 0;
    }

    _injectFilesByRule(tabId, rule) {
        for (let file of rule.js) {
            chrome.tabs.executeScript(tabId, ((rule, file) => PassiveStrategy._getDetails(rule, file))(rule, file), function () {
                if (chrome.runtime.lastError) {
                    //toDo: add error handler
                }
            });
        }
    }

    start() {
        chrome.webNavigation.onCompleted.addListener(function (details) {
            if (details.frameId == 0) {
                chrome.tabs.get(details.tabId, function (tab) {
                    if (!chrome.runtime.lastError && tab && tab.id && PassiveStrategy._isSuitablePassiveInjection(tab)) {
                        for (let rule of passivePluginRules) {
                            if (PassiveStrategy._matches(tab.url, rule.matches)) {
                                this._injectFilesByRule(tab.id, rule);
                            }
                        }
                    }
                }.bind(this));
            }
        }.bind(this));
    }
}
