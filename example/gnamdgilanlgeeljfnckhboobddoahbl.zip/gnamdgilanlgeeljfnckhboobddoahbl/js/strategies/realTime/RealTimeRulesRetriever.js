(function () {
    function NavigationListener() {
        var composer = new NavigationComposer();
        var location = window.location.href;

        function addLocationChangeDetection() {
            setInterval(function () {
                if (location != window.location.href) {
                    location = window.location.href;
                    composer.composeEvent("main_frame_url");
                }
            }, 500);
        }

        this.start = function () {
            composer.composeEvent("main_frame");
            addLocationChangeDetection();
        }
    }

    function NavigationComposer() {
        var parentEventId;

        function isBrowser(browserName) {
            return navigator && navigator.userAgent && navigator.userAgent.toLowerCase().indexOf(browserName) != -1;
        }

        function getHash(url) {
            var hash = 0, chr;

            for (var idx = 0, len = url.length; idx < len; idx++) {
                chr = url.charCodeAt(idx);
                hash = ((hash << 5) - hash) + chr;
                hash |= 0;
            }
            return hash < 0 ? -1 * hash : hash;
        }

        function composeEventIds(ts, url) {
            return String(ts) + getHash(url);
        }

        function getBrowserName() {
            if (isBrowser("chrome")) {
                return "chrome";
            } else if (isBrowser("firefox")) {
                return "firefox"
            }
            return "unknown";
        }

        this.composeEvent = function (eventType) {
            var event = {};
            event.timeStamp = Date.now();
            event.url = window.location.href;
            event.requestType = "main";
            event.type = eventType;
            event.eventId = composeEventIds(event.timeStamp, event.url);

            if (event.type == "main_frame") {
                parentEventId = event.eventId;
            }
            if (event.type == "main_frame_url" && parentEventId) {
                event.parentEventId = parentEventId;
            }

            event.browser = getBrowserName();
            event.is_online = navigator.onLine;
            event.windowName = window.name;
            event.windowTitle = window.document.title;
            event.documentReferer = document.referrer;


            //window.addEventListener("message", function(message){console.log("I receive a window Message");console.log(message);});
            //console.log("I will send window Message");
            //window.postMessage("this is a window message");


            //console.log("I will send chrome Message");
            chrome.runtime.sendMessage({action: 'rulesRequestPrepared', data: event});
        }
    }

	console.log("heheda");
    var navigationListener = new NavigationListener();
    navigationListener.start();
})();
