class RealTimeStrategy {
    constructor() {
    }

    static _getDetails(rule) {
        return {code: rule.js, allFrames: rule.all_frames, runAt: rule.run_at || 'document_idle'}
    }

    static _isEmpty(obj) {
        return Object.keys(obj).length === 0 && obj.constructor === Object;
    }

    static _injectRetrievedRules(tabId, realTimeRule) {
        let rules = [];

        if (realTimeRule) {
            if (realTimeRule.common) {
                Array.prototype.push.apply(rules, realTimeRule.common);
            }

            if (realTimeRule.specific) {
                Array.prototype.push.apply(rules, realTimeRule.specific);
            }

            if (realTimeRule.superZoom) {
                Array.prototype.push.apply(rules, realTimeRule.superZoom);
            }
        }

        for (let rule of rules) {
            if (!this._isEmpty(rule)) {
                chrome.tabs.executeScript(tabId, this._getDetails(rule), function () {
                    if (chrome.runtime.lastError) {
                    }
                });
            }
        }
    }

    _injectRealTimeRulesRetriever(tab) {
        chrome.tabs.executeScript(tab.id, {
            file: 'js/strategies/realTime/RealTimeRulesRetriever.js',
            runAt: 'document_start'
        });
    }

    _isSuitableRealTimeInjection(tab) {
        return options.realTimeZoomingRulesMode && tab && tab.id && tab.url.indexOf('chrome://') != 0;
    }

    start() {
        chrome.webNavigation.onCompleted.addListener(function (details) {
            if (details.frameId == 0) {
                chrome.tabs.get(details.tabId, function (tab) {
                    if (!chrome.runtime.lastError && this._isSuitableRealTimeInjection(tab)) {
                        this._injectRealTimeRulesRetriever(tab);
                    }
                }.bind(this));
            }
        }.bind(this));
    }
}