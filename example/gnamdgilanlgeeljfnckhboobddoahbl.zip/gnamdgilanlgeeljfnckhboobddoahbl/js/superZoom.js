var superZoomPlugins = superZoomPlugins || [];

var superZoom = {
    options: {},
    currentLink: null,
    szImg: null,
    szImgCss: {
        'border': '1px solid #e3e3e3',
        'line-height': 0,
        'overflow': 'hidden',
        'padding': '2px',
        'margin': 0,
        'position': 'absolute',
        'z-index': 2147483647,
        'border-radius': '3px',
        'background': 'linear-gradient(to right bottom, #ffffff, #ffffff 50%, #ededed)',
        'box-shadow': '3px 3px 9px 5px rgba(0,0,0,0.33)'
    },
    imgLoading: null,
    pageGenerator: '',

    loadSuperZoom: function () {
        var sz = superZoom,
            wnd = $(window),
            body = $(document.body),
            szCaption = null,
            szGallery = null,
            imgFullSize = null,
            imgThumb = null,
            mousePos = {},
            loading = false,
            loadFullSizeImageTimeout,
            preloadTimeout,
            actionKeyDown = false,
            fullZoomKeyDown = false,
            hideKeyDown = false,
            pageActionShown = false,
            skipFadeIn = false,
            titledElements = null,
            body100pct = true,
            linkRect = null;

        var imgDetails = {
            url: '',
            host: '',
            naturalHeight: 0,
            naturalWidth: 0
        };

        var progressCss = {
                'opacity': '0.5',
                'position': 'absolute',
                'max-height': '22px',
                'max-width': '22px',
                'left': '3px',
                'top': '3px',
                'margin': '0',
                'padding': '0',
                'border-radius': '2px'
            },
            imgFullSizeCss = {
                'opacity': '1',
                'position': 'static',
                'height': 'auto',
                'width': 'auto',
                'left': 'auto',
                'top': 'auto',
                'max-height': 'none',
                'max-width': 'none',
                'margin': '0',
                'padding': '0',
                'border-radius': '0',
                'background-size': '100% 100%',
                'background-position': 'center',
                'background-repeat': 'no-repeat'
            },
            szCaptionCss = {
                'font': 'menu',
                'font-size': '11px',
                'font-weight': 'bold',
                'color': '#333',
                'text-align': 'center',
                'max-height': '27px',
                'overflow': 'hidden',
                'vertical-align': 'top'
            },
            szGalleryInfoCss = {
                'position': 'absolute',
                'top': '5px',
                'right': '5px',
                'font': 'menu',
                'font-size': '14px',
                'font-weight': 'bold',
                'color': 'white',
                'text-shadow': '-1px 0 black, 0 1px black, 1px 0 black, 0 -1px black',
                'text-align': 'center',
                'overflow': 'hidden',
                'vertical-align': 'top',
                'horizontal-align': 'right'
            };


        // Calculate optimal image position and size
        function posImg(position) {
            if (!imgFullSize) {
                return;
            }

            if (position === undefined || position.top === undefined || position.left === undefined) {
                position = {top: mousePos.top, left: mousePos.left};
            }

            var offset = 20,
                padding = 10,
                statusBarHeight = 15,
                wndWidth = window.innerWidth,
                wndHeight = window.innerHeight,
                wndScrollLeft = (document.documentElement && document.documentElement.scrollLeft) || document.body.scrollLeft,
                wndScrollTop = (document.documentElement && document.documentElement.scrollTop) || document.body.scrollTop,
                bodyWidth = document.body.clientWidth,
                displayOnRight = (position.left - wndScrollLeft < wndWidth / 2);

            function posCaption() {
                if (szCaption) {
                    szCaption.css('max-width', imgFullSize.width());
                    if (szCaption.height() > 20) {
                        szCaption.css('font-weight', 'normal');
                    }
                    // This is looped 10x max just in case something
                    // goes wrong, to avoid freezing the process.
                    var i = 0;
                    while (sz.szImg.height() > wndHeight - statusBarHeight && i++ < 10) {
                        imgFullSize.height(wndHeight - padding - statusBarHeight - szCaption.height()).width('auto');
                        szCaption.css('max-width', imgFullSize.width());
                    }
                }
            }

            if (displayOnRight) {
                position.left += offset;
            } else {
                position.left -= offset;
            }

            if (sz.imgLoading) {
                position.top -= 10;
                if (!displayOnRight) {
                    position.left -= 25;
                }
            } else {
                var fullZoom = options.mouseUnderlap || fullZoomKeyDown;

                imgFullSize.width('auto').height('auto');

                // Image natural dimensions
                imgDetails.naturalWidth = imgFullSize.width() * options.zoomFactor;
                imgDetails.naturalHeight = imgFullSize.height() * options.zoomFactor;
                if (!imgDetails.naturalWidth || !imgDetails.naturalHeight) {
                    return;
                }

                // Width adjustment
                if (fullZoom) {
                    imgFullSize.width(Math.min(imgDetails.naturalWidth, wndWidth - padding + wndScrollLeft));
                } else {
                    if (displayOnRight) {
                        if (imgDetails.naturalWidth + padding > wndWidth - position.left) {
                            imgFullSize.width(wndWidth - position.left - padding + wndScrollLeft);
                        }
                    } else {
                        if (imgDetails.naturalWidth + padding > position.left) {
                            imgFullSize.width(position.left - padding - wndScrollLeft);
                        }
                    }
                }

                // Height adjustment
                if (sz.szImg.height() > wndHeight - padding - statusBarHeight) {
                    imgFullSize.height(wndHeight - padding - statusBarHeight).width('auto');
                }

                posCaption();

                position.top -= sz.szImg.height() / 2;

                // Display image on the left side if the mouse is on the right
                if (!displayOnRight) {
                    position.left -= sz.szImg.width() + padding;
                }

                // Horizontal position adjustment if full zoom
                if (fullZoom) {
                    if (displayOnRight) {
                        position.left = Math.min(position.left, wndScrollLeft + wndWidth - sz.szImg.width() - padding);
                    } else {
                        position.left = Math.max(position.left, wndScrollLeft);
                    }
                }

                // Vertical position adjustments
                var maxTop = wndScrollTop + wndHeight - sz.szImg.height() - padding - statusBarHeight;
                if (position.top > maxTop) {
                    position.top = maxTop;
                }
                if (position.top < wndScrollTop) {
                    position.top = wndScrollTop;
                }
            }

            // This fixes positioning when the body's width is not 100%
            if (body100pct) {
                position.left -= (wndWidth - bodyWidth) / 2;
            }

            sz.szImg.css({top: Math.round(position.top), left: Math.round(position.left)});
        }

        function posWhileLoading() {
            if (loading) {
                posImg();
                if (sz.imgLoading && imgFullSize && imgFullSize.height() > 0) {
                    displayFullSizeImage();
                } else {
                    setTimeout(posWhileLoading, 100);
                }
            }
        }

        // Remove the 'title' attribute from all elements to prevent a tooltip from appearing above the zoomed image.
        // Titles are saved so they can be restored later.
        function removeTitles() {
            if (titledElements) {
                return;
            }
            titledElements = $('[title]').not('iframe, .lightbox, [rel^="lightbox"]');
            titledElements.each(function () {
                $(this).data().superZoomTitle = this.getAttribute('title');
                this.removeAttribute('title');
            });
        }

        // Restore the 'title' attributes
        function restoreTitles() {
            if (!titledElements) {
                return;
            }
            titledElements.each(function () {
                if ($(this).data()) {
                    this.setAttribute('title', $(this).data().superZoomTitle);
                }
            });
            titledElements = null;
        }

        function hideSuperZoomImg(now) {
            if ((!now && !imgFullSize) || !sz.szImg || fullZoomKeyDown) {
                return;
            }
            imgFullSize = null;
            if (loading) {
                now = true;
            }
            sz.szImg.stop(true, true).fadeOut(now ? 0 : options.fadeDuration, function () {
                szCaption = null;
                sz.imgLoading = null;
                sz.szImg.empty();
                restoreTitles();
            });
        }

        function documentMouseMove(event) {
            if (fullZoomKeyDown || wnd.height() < 30 || wnd.width() < 30) {
                return;
            }

            var links,
                target = $(event.target),
            // Test if the action key was pressed without moving the mouse
                explicitCall = event.pageY == undefined;

            // If so, the MouseMove event was triggered programmaticaly and we don't have details
            // about the mouse position and the event target, so we use the last saved ones.
            if (explicitCall) {
                links = sz.currentLink;
            } else {
                mousePos = {top: event.pageY, left: event.pageX};
                links = target.parents('.superZoomLink');
                if (target.hasClass('superZoomLink')) {
                    links = links.add(target);
                }
            }

            if (options.mouseUnderlap && target.length && mousePos && linkRect &&
                (imgFullSize && imgFullSize.length && target[0] == imgFullSize[0] ||
                sz.szImg && sz.szImg.length && target[0] == sz.szImg[0])) {
            }

            if (links && links.length > 0) {
                var superZoomSrcIndex = links.data().superZoomSrcIndex || 0;
                if (links.data().superZoomSrc && typeof(links.data().superZoomSrc) != 'undefined' &&
                    links.data().superZoomSrc[superZoomSrcIndex] &&
                    typeof(links.data().superZoomSrc[superZoomSrcIndex]) != 'undefined') {
                    // Happens when the mouse goes from an image to another without supering the page background
                    if (links.data().superZoomSrc[superZoomSrcIndex] != imgDetails.url) {
                        hideSuperZoomImg();
                    }

                    removeTitles();

                    // If the image source has not been set yet
                    if (!imgFullSize) {
                        sz.currentLink = links;
                        //initLinkRect(sz.currentLink);
                        if (!options.actionKey || actionKeyDown) {
                            var src = links.data().superZoomSrc[superZoomSrcIndex];
                            if (src.indexOf('http') !== 0) {
                                if (src.indexOf('//') !== 0) {
                                    if (src.indexOf('/') === 0) {
                                        // Image has absolute path (starts with '/')
                                        src = src.substr(1);
                                    } else {
                                        // Image has relative path (doesn't start with '/')
                                        var path = window.location.pathname;
                                        path = path.substr(0, path.lastIndexOf('/') + 1);
                                        src = path + src;
                                    }
                                    src = '//' + window.location.host + '/' + src;
                                }
                                src = window.location.protocol + src;
                            }
                            imgDetails.url = src;
                            clearTimeout(loadFullSizeImageTimeout);

                            // If the action key has been pressed over an image, no delay is applied
                            var delay = actionKeyDown || explicitCall ? 0 : options.displayDelay;
                            loadFullSizeImageTimeout = setTimeout(loadFullSizeImage, delay);

                            loading = true;
                        }
                    } else {
                        posImg();
                    }
                }
            } else if (sz.currentLink) {
                cancelImageLoading();
            }
        }

        function documentMouseDown(event) {
            if (imgFullSize && event.target != sz.szImg[0] && event.target != imgFullSize[0]) {
                cancelImageLoading();
                restoreTitles();
            }
        }

        function loadFullSizeImage() {
            // If no image is currently displayed...
            if (!imgFullSize) {
                sz.createHzImg(!hideKeyDown);
                sz.createImgLoading();

                imgFullSize = $('<img style="border: none" />').appendTo(sz.szImg).load(imgFullSizeOnLoad).error(imgFullSizeOnError).attr('src', imgDetails.url);
                imgDetails.host = getHostFromUrl(imgDetails.url);

                skipFadeIn = false;
                imgFullSize.css(progressCss);
                if (options.showWhileLoading) {
                    posWhileLoading();
                }
                posImg();
            }
            posImg();
        }

        function imgFullSizeOnLoad() {
            // Only the last supered link gets displayed
            if (imgDetails.url == $(imgFullSize).attr('src')) {
                loading = false;
                if (sz.imgLoading) {
                    displayFullSizeImage();
                }
            }
        }

        function initLinkRect(elem) {
            linkRect = elem.offset();
            linkRect.bottom = linkRect.top + elem.height();
            linkRect.right = linkRect.left + elem.width();
        }

        function displayFullSizeImage() {
            sz.imgLoading.remove();
            sz.imgLoading = null;
            sz.szImg.stop(true, true);
            sz.szImg.offset({top: -9000, left: -9000});    // hides the image while making it available for size calculations
            sz.szImg.empty();

            clearTimeout(cursorHideTimeout);
            sz.szImg.css('cursor', 'none');

            imgFullSize.css(imgFullSizeCss).appendTo(sz.szImg).mousemove(imgFullSizeOnMouseMove);

            if (sz.currentLink) {
                // Sets up the thumbnail as a full-size background
                imgThumb = sz.currentLink;
                var lowResSrc = imgThumb.attr('src');
                if (!lowResSrc) {
                    imgThumb = sz.currentLink.find('[src]');
                    if (imgThumb.length > 0) {
                        imgThumb = $(imgThumb[0]);
                        lowResSrc = imgThumb.attr('src');
                    }
                }
                if (!lowResSrc) {
                    imgThumb = sz.currentLink.find('[style]');
                    if (imgThumb.length > 0) {
                        imgThumb = $(imgThumb[0]);
                        lowResSrc = sz.getThumbUrl(imgThumb);
                    }
                }
                lowResSrc = lowResSrc || 'noimage';
                if (loading && lowResSrc.indexOf('noimage') == -1) {
                    var ext = imgDetails.url.substr(imgDetails.url.length - 3).toLowerCase();
                    if (ext != 'gif' && ext != 'svg' && ext != 'png') {
                        var imgRatio = imgFullSize.width() / imgFullSize.height(),
                            thumbRatio = imgThumb.width() / imgThumb.height();
                        // The thumbnail is used as a background only if its width/height ratio is similar to the image
                        if (Math.abs(imgRatio - thumbRatio) < 0.1)
                            imgFullSize.css({'background-image': 'url(' + lowResSrc + ')'});
                    }
                } else {
                    imgThumb = null;
                }

                sz.szImg.css('cursor', 'pointer');

                initLinkRect(imgThumb || sz.currentLink);
            }

            if (sz.currentLink) {
                var linkData = sz.currentLink.data();
                if (options.showCaptions && linkData.superZoomCaption) {
                    szCaption = $('<div/>', {
                        id: 'szCaption',
                        text: linkData.superZoomCaption
                    }).css(szCaptionCss).appendTo(sz.szImg);
                }
                if (linkData.superZoomGallerySrc && linkData.superZoomGallerySrc.length > 1) {
                    var info = (linkData.superZoomGalleryIndex + 1) + '/' + linkData.superZoomGallerySrc.length;
                    szGallery = $('<div/>', {id: 'szGallery', text: info}).css(szGalleryInfoCss).appendTo(sz.szImg);
                    if (linkData.superZoomGalleryIndex == 0 && linkData.superZoomGallerySrc.length > 1) {
                        preloadGalleryImage(1);
                    }
                }
            }

            if (!skipFadeIn && !hideKeyDown) {
                sz.szImg.hide().fadeTo(options.fadeDuration, options.picturesOpacity);
            }

            // The image size is not yet available in the onload so I have to delay the positioning
            setTimeout(posImg, options.showWhileLoading ? 0 : 10);

            if (options.addToHistory && !chrome.extension.inIncognitoContext) {
                var url = sz.currentLink.context.href || imgDetails.url;
                chrome.runtime.sendMessage({action: 'addUrlToHistory', url: url});
            }
        }

        function imgFullSizeOnError() {
            if (imgDetails.url == $(this).attr('src')) {
                var superZoomSrcIndex = sz.currentLink ? sz.currentLink.data().superZoomSrcIndex : 0;
                if (sz.currentLink && superZoomSrcIndex < sz.currentLink.data().superZoomSrc.length - 1) {
                    // If the link has several possible sources, we try to load the next one
                    imgFullSize.remove();
                    imgFullSize = null;
                    superZoomSrcIndex++;
                    sz.currentLink.data().superZoomSrcIndex = superZoomSrcIndex;
                    console.info('[SuperZoom] Failed to load image: ' + imgDetails.url + '\nTrying next one...');
                    imgDetails.url = sz.currentLink.data().superZoomSrc[superZoomSrcIndex];
                    setTimeout(loadFullSizeImage, 100);
                } else {
                    hideSuperZoomImg();
                    //sz.currentLink.removeClass('superZoomLink').removeData();
                    console.warn('[SuperZoom] Failed to load image: ' + imgDetails.url);
                }
            }
        }

        var firstMouseMoveAfterCursorHide = false,
            cursorHideTimeout = 0;

        function hideCursor() {
            firstMouseMoveAfterCursorHide = true;
            sz.szImg.css('cursor', 'none');
        }

        function imgFullSizeOnMouseMove() {
            if (!imgFullSize && !options.mouseUnderlap) {
                hideSuperZoomImg(true);
            }
            clearTimeout(cursorHideTimeout);
            if (!firstMouseMoveAfterCursorHide) {
                sz.szImg.css('cursor', 'pointer');
                cursorHideTimeout = setTimeout(hideCursor, 500);
            }
            firstMouseMoveAfterCursorHide = false;
        }

        function cancelImageLoading() {
            sz.currentLink = null;
            clearTimeout(loadFullSizeImageTimeout);
            hideSuperZoomImg();
        }

        function prepareImgCaption(link) {
            var titledElement = null;
            if (link.attr('title')) {
                titledElement = link;
            } else {
                titledElement = link.find('[title]');
                if (!titledElement.length) {
                    titledElement = link.parents('[title]');
                }
            }
            if (titledElement && titledElement.length) {
                link.data().superZoomCaption = titledElement.attr('title');
            } else {
                var alt = link.attr('alt') || link.find('[alt]').attr('alt');
                if (alt && alt.length > 6 && !/^\d+$/.test(alt)) {
                    link.data().superZoomCaption = alt;
                } else {
                    var ref = link.attr('ref') || link.find('[ref]').attr('ref');
                    if (ref && ref.length > 6 && !/^\d+$/.test(ref)) {
                        link.data().superZoomCaption = ref;
                    }
                }
            }
        }

        // Callback function called by plugins after they finished preparing the links
        function imgLinksPrepared(links) {
            links.each(function () {
                var link = $(this),
                    linkData = link.data();
                if (!linkData.superZoomSrc && !linkData.superZoomGallerySrc) {

                    prepareImgLinksAsync(true);

                } else {

                    // Skip if the image has the same URL as the thumbnail.
                    //try {
                    if (linkData.superZoomSrc) {
                        var url = linkData.superZoomSrc[0],
                            skip = (url == link.attr('src'));
                        if (!skip) {
                            link.find('img[src]').each(function () {
                                if (this.src == url) {
                                    skip = true;
                                }
                            });
                        }
                        if (skip) {
                            return;
                        }
                    }

                    // If the extension is disabled or the site is excluded, we only need to know
                    // whether the page action needs to be shown or not.

                    link.addClass('superZoomLink');

                    // Convert URL special characters
                    if (linkData.superZoomGallerySrc) {
                        if (!linkData.superZoomGalleryIndex)
                            linkData.superZoomGalleryIndex = 0;
                        linkData.superZoomGallerySrc = linkData.superZoomGallerySrc.map(function (srcs) {
                            return srcs.map(deepUnescape);
                        });
                        updateImageFromGallery(link);
                    } else {
                        linkData.superZoomSrc = linkData.superZoomSrc.map(deepUnescape);
                    }

                    linkData.superZoomSrcIndex = 0;

                    // Caption
                    if (options.showCaptions && !linkData.superZoomCaption) {
                        prepareImgCaption(link);
                    }
                }
            });
        }

        function prepareImgLinks() {
            pageActionShown = false;

            for (var i = 0; i < superZoomPlugins.length; i++) {
                if (!options.disabledPlugins.includes(superZoomPlugins[i].name.replace(/[^\w]/g, '').toLowerCase()))
                    superZoomPlugins[i].prepareImgLinks(imgLinksPrepared);
            }
            prepareImgLinksTimeout = null;

            if (options.alwaysPreload) {
                clearTimeout(preloadTimeout);
                preloadTimeout = setTimeout(sz.preloadImages, 800);
            } else {
                chrome.runtime.sendMessage({action: 'preloadAvailable'});
            }

            prepareDownscaledImagesAsync();
        }

        var prepareDownscaledImagesDelay = 500, prepareDownscaledImagesTimeout;

        function prepareDownscaledImagesAsync(dontResetDelay) {
            if (!dontResetDelay) {
                prepareDownscaledImagesDelay = 500;
            }
            clearTimeout(prepareDownscaledImagesTimeout);
            prepareDownscaledImagesTimeout = setTimeout(prepareDownscaledImages, prepareDownscaledImagesDelay);
            prepareDownscaledImagesDelay *= 2;
        }

        function prepareDownscaledImages() {
            // Excluded sites
            if (['www.facebook.com'].indexOf(location.host) > -1) {
                return;
            }

            $('img').filter(function () {
                var _this = $(this);

                // Only zoom jpg images, to prevent zooming on images that are part of the site design
                if (this.src.toLowerCase().lastIndexOf('.jpg') != this.src.length - 4) {
                    return false;
                }

                // Using _this.data('superZoomSrc') breaks some multi-frames sites (don't know why...)
                if (_this.data().superZoomSrc) {
                    return false;
                }

                // Don't process when the image is the only element on the page (well, first element).
                if (this == document.body.firstChild) {
                    return false;
                }

                // Only images with a specified width, height, max-width or max-weight are processed.
                var scaled = this.getAttribute('width') || this.getAttribute('height') ||
                    this.style && (this.style.width || this.style.height || this.style.maxWidth || this.style.maxHeight);
                if (!scaled) {
                    scaled = scaled || _this.css('width') != '0px' || _this.css('height') != '0px' || _this.css('max-width') != 'none' || _this.css('max-height') != 'none';
                }
                return scaled;
            }).one('mouseover.superZoom', function () {
                var img = $(this),
                    widthAttr = parseInt(this.getAttribute('width') || this.style.width || this.style.maxWidth || img.css('width') || img.css('max-width')),
                    heightAttr = parseInt(this.getAttribute('height') || this.style.height || this.style.maxHeight || img.css('height') || img.css('max-height')),
                    szDownscaled = $('<img id="szDownscaled" style="position: absolute; top: -10000px;">').appendTo(document.body);

                szDownscaled.load(function () {
                    setTimeout(function () {
                        if (szDownscaled.height() > heightAttr || szDownscaled.width() > widthAttr) {
                            var srcs = img.data().superZoomSrc || [];
                            srcs.unshift(img.attr('src'));
                            img.data().superZoomSrc = srcs;
                            img.addClass('superZoomLink');
                        }
                        szDownscaled.remove();
                    }, 10);
                }).attr('src', this.src);
            });
        }

        var prepareImgLinksDelay = 500, prepareImgLinksTimeout;

        function prepareImgLinksAsync(dontResetDelay) {
            if (!dontResetDelay) {
                prepareImgLinksDelay = 500;
            }

            clearTimeout(prepareImgLinksTimeout);
            prepareImgLinksTimeout = setTimeout(prepareImgLinks, prepareImgLinksDelay);
            prepareImgLinksDelay *= 2;
        }

        function deepUnescape(url) {
            var ueUrl = unescape(encodeURIComponent(url));
            while (url != ueUrl) {
                url = ueUrl;
                ueUrl = unescape(url);
            }
            return decodeURIComponent(escape(url));
        }

        function loadOptions() {
            chrome.runtime.sendMessage({action: 'getOptions'}, function (result) {
                options = result;
                if (options && options.passiveZoomingRulesMode) {
                    init();
                }
            });
        }

        function onMessage(message, sender, sendResponse) {
            if (message.action == 'optionsChanged') {
                options = message.options;
                init();
            }
        }

        function windowOnDOMNodeInserted(event) {
            var insertedNode = event.target;
            if (insertedNode && insertedNode.nodeType === Node.ELEMENT_NODE) {
                if (insertedNode.nodeName === 'A' ||
                    insertedNode.nodeName === 'IMG' ||
                    insertedNode.getElementsByTagName('A').length > 0 ||
                    insertedNode.getElementsByTagName('IMG').length > 0) {
                    if (insertedNode.id !== 'szImg' &&
                        insertedNode.parentNode.id !== 'szImg' &&
                        insertedNode.id !== 'szDownscaled') {
                        prepareImgLinksAsync();
                    }
                } else if (insertedNode.nodeName === 'EMBED' || insertedNode.nodeName === 'OBJECT') {
                    fixFlash();
                }
            }
        }

        function windowOnLoad(event) {
            prepareImgLinksAsync();
        }

        function bindEvents() {
            wnd.bind('DOMNodeInserted', windowOnDOMNodeInserted).load(windowOnLoad).scroll(cancelImageLoading);
            $(document).mousemove(documentMouseMove).mouseleave(cancelImageLoading).mousedown(documentMouseDown);
            if (options.galleriesMouseWheel) {
                $(document).on('mousewheel', documentOnMouseWheel);
            }
        }

        function documentOnMouseWheel(event) {
            if (imgFullSize && sz.currentLink) {
                var data = sz.currentLink.data();
                if (data.superZoomGallerySrc && data.superZoomGallerySrc.length !== 1) {
                    event.preventDefault();
                    if (event.originalEvent.wheelDeltaY > 0) {
                        rotateGalleryImg(-1);
                    } else {
                        rotateGalleryImg(1);
                    }
                }
            }
        }

        function fixFlash() {
            var flashFixDomains = [
                'www.redditmedia.com'
            ];

            if (flashFixDomains.indexOf(location.host) == -1) {
                return;
            }
            if (window == window.top && $('.superZoomLink').length == 0) {
                return;
            }
            $('embed:not([wmode]), embed[wmode="window"]').each(function () {
                if (!this.type || this.type.toLowerCase() != 'application/x-shockwave-flash') {
                    return;
                }
                var embed = this.cloneNode(true);
                embed.setAttribute('wmode', 'opaque');
                wnd.unbind('DOMNodeInserted', windowOnDOMNodeInserted);
                $(this).replaceWith(embed);
                wnd.bind('DOMNodeInserted', windowOnDOMNodeInserted);
            });
            var wmodeFilter = function () {
                return this.name.toLowerCase() == 'wmode';
            };
            $('object[type="application/x-shockwave-flash"]').filter(function () {
                var param = $(this).children('param').filter(wmodeFilter);
                return param.length == 0 || param.attr('value').toLowerCase() == 'window';
            }).each(function () {
                var object = this.cloneNode(true);
                $(object).children('param').filter(wmodeFilter).remove();
                $('<param name="wmode" value="opaque">').appendTo(object);
                wnd.unbind('DOMNodeInserted', windowOnDOMNodeInserted);
                $(this).replaceWith(object);
                wnd.bind('DOMNodeInserted', windowOnDOMNodeInserted);
            });
        }

        function getHostFromUrl(url) {
            var host = '';
            if (url.indexOf('://') > -1) {
                host = url.replace(/.+:\/\/([^\/]*).*/, '$1');
            } else {
                host = window.location.host;
            }
            var aHost = host.split('.'),
                maxItems = 2;
            if (aHost.length > 2) {
                var preTld = aHost[aHost.length - 2];
                if (preTld == 'co' || preTld == 'com' || preTld == 'net' || preTld == 'org') {
                    maxItems = 3;
                }
            }
            while (aHost.length > maxItems) {
                aHost.shift();
            }
            return aHost.join('.');
        }

        function rotateGalleryImg(rot) {
            var link = sz.currentLink, data = link.data();
            if (!data.superZoomGallerySrc) {
                return;
            }

            var l = data.superZoomGallerySrc.length;
            data.superZoomGalleryIndex = (data.superZoomGalleryIndex + rot + l) % l;
            updateImageFromGallery(link);

            data.superZoomSrcIndex = 0;
            loading = true;
            szGallery.text('.../' + data.superZoomGallerySrc.length);

            loadNextGalleryImage();
            preloadGalleryImage((data.superZoomGalleryIndex + rot + l) % l);
        }

        function loadNextGalleryImage() {
            clearTimeout(loadFullSizeImageTimeout);
            imgDetails.url = sz.currentLink.data().superZoomSrc[sz.currentLink.data().superZoomSrcIndex];
            imgFullSize.load(nextGalleryImageOnLoad).error(function () {
                imgOnError(this, false, loadNextGalleryImage);
            }).attr('src', imgDetails.url);
        }

        function nextGalleryImageOnLoad() {
            if (loading) {
                loading = false;
                posImg();

                data = sz.currentLink.data();
                if (data.superZoomGallerySrc.length > 0) {
                    szGallery.text((data.superZoomGalleryIndex + 1) + '/' + data.superZoomGallerySrc.length);
                }
                if (options.showCaptions) {
                    $(szCaption).text(data.superZoomCaption);
                }
            }
        }

        function updateImageFromGallery(link) {
            if (options.enableGalleries) {
                var data = link.data();
                data.superZoomSrc = data.superZoomGallerySrc[data.superZoomGalleryIndex];

                if (data.superZoomGalleryCaption) {
                    data.superZoomCaption = data.superZoomGalleryCaption[data.superZoomGalleryIndex];
                } else {
                    prepareImgCaption(link);
                }
            }
        }

        function preloadGalleryImage(index) {
            var preloadImg = new Image();
            preloadImg.src = sz.currentLink.data().superZoomGallerySrc[index][0];
        }

        function init() {
            if (!window.innerHeight || !window.innerWidth) {
                return;
            }

            body100pct = (body.css('position') != 'static') ||
                (body.css('padding-left') == '0px' && body.css('padding-right') == '0px' && body.css('margin-left') == '0px' && body.css('margin-right') == '0px');
            sz.pageGenerator = $('meta[name="generator"]').attr('content');
            prepareImgLinks();
            bindEvents();
            fixFlash();
        }

        chrome.runtime.onMessage.addListener(onMessage);
        loadOptions();
    },

    // __________________________________________________________________
    // Public functions

    // Search for links or images using the 'filter' parameter,
    // process their src or href attribute using the 'search' and 'replace' values,
    // store the result in the link and add the link to the 'res' array.
    urlReplace: function (res, filter, search, replace, parentFilter) {
        $(filter).each(function () {
            var _this = $(this), link, url, thumbUrl;
            if (parentFilter) {
                link = _this.parents(parentFilter);
            } else {
                link = _this;
            }
            url = superZoom.getThumbUrl(this);
            if (!url) {
                return;
            }
            thumbUrl = url;
            if (Array.isArray(search)) {
                for (var i = 0; i < search.length; i++) {
                    url = url.replace(search[i], replace[i]);
                }
            } else {
                url = url.replace(search, replace);
            }
            url = unescape(url);
            if (thumbUrl == url) {
                return;
            }
            var data = link.data().superZoomSrc;
            if (Object.prototype.toString.call(data) === '[object Array]') {
                data.unshift(url);
            } else {
                data = [url];
            }
            link.data().superZoomSrc = data;
            res.push(link);
        });
    },

    // Extract a thumbnail url from an element, whether it be a link,
    // an image or a element with a background image.
    getThumbUrl: function (el) {
        var compStyle = (el && el.nodeType == 1) ? getComputedStyle(el) : false,
            backgroundImage = compStyle ? compStyle.backgroundImage : 'none';
        if (backgroundImage != 'none') {
            return backgroundImage.replace(/.*url\s*\(\s*(.*)\s*\).*/i, '$1');
        } else {
            return el.src || el.href;
        }
    },

    // Simulates a mousemove event to force a zoom call
    displayPicFromElement: function (el) {
        superZoom.currentLink = el;
        $(document).mousemove();
    },

    // Create and displays the zoomed image container
    createHzImg: function (displayNow) {
        if (!superZoom.szImg) {
            superZoom.szImg = $('<div id="szImg"></div>').appendTo(document.body);

            // If the user clicks the image, this simulates a click underneath
            superZoom.szImg.click(function (event) {
                if (superZoom.currentLink && superZoom.currentLink.length) {
                    var simEvent = document.createEvent('MouseEvents');
                    simEvent.initMouseEvent('click', event.bubbles, event.cancelable, event.view, event.detail,
                        event.screenX, event.screenY, event.clientX, event.clientY,
                        event.ctrlKey, event.altKey, event.shiftKey, event.metaKey, event.button, null);
                    superZoom.currentLink[0].dispatchEvent(simEvent);
                }
            });

        }
        superZoom.szImg.css(superZoom.szImgCss);
        superZoom.szImg.empty();
        if (displayNow) {
            superZoom.szImg.stop(true, true).fadeTo(options.fadeDuration, options.picturesOpacity);
        }
    },

    // Create and displays the loading image container
    createImgLoading: function () {
        superZoom.imgLoading = superZoom.imgLoading || $('<img src="' + chrome.extension.getURL('images/loading.gif') + '" style="opacity: 0.8; padding: 0; margin: 0" />');
        superZoom.imgLoading.appendTo(superZoom.szImg);
    },

    // Preloads zoomed images
    preloadImages: function () {

        var links = $('.superZoomLink'),
            preloadIndex = 0,
            preloadDelay = 200;

        function preloadNextImage() {
            if (preloadIndex >= links.length) {
                return;
            }
            var link = links.eq(preloadIndex++);
            if (link.data().superZoomPreloaded) {
                preloadNextImage();
                chrome.runtime.sendMessage({action: 'preloadProgress', value: preloadIndex, max: links.length});
            } else {
                var superZoomSrcIndex = link.data().superZoomSrcIndex || 0;
                $('<img>', {src: link.data().superZoomSrc[superZoomSrcIndex]}).load(function () {
                    link.data().superZoomPreloaded = true;
                    setTimeout(preloadNextImage, preloadDelay);
                    chrome.runtime.sendMessage({action: 'preloadProgress', value: preloadIndex, max: links.length});
                }).error(function () {
                    if (superZoomSrcIndex < link.data().superZoomSrc.length - 1) {
                        link.data().superZoomSrcIndex++;
                        preloadIndex--;
                    }
                    setTimeout(preloadNextImage, preloadDelay);
                });
            }
        }

        setTimeout(preloadNextImage, preloadDelay);
    },

    prepareOEmbedLink: function (link, apiEndpoint, linkUrl) {
        if (!linkUrl) {
            linkUrl = getThumbUrl(link);
        }
        link = $(link);
        $.ajax({
            dataType: "json",
            jsonp: false,
            url: apiEndpoint + linkUrl,
            success: function (data) {
                if (data && data.type == 'photo' && data.url) {
                    link.data().superZoomSrc = [data.url];
                    link.addClass('superZoomLink');
                    superZoom.displayPicFromElement(link);
                }
            }
        });
    },

    prepareFromDocument: function (link, url, getSrc) {
        $.get(url, function (data) {
            var doc = document.implementation.createHTMLDocument();
            doc.open();
            doc.write(data);
            doc.close();
            var httpRefresh = doc.querySelector('meta[http-equiv="refresh"][content]');
            if (httpRefresh) {
                var redirUrl = httpRefresh.content.substr(httpRefresh.content.toLowerCase().indexOf('url=') + 4);
                if (redirUrl) {
                    redirUrl = redirUrl.replace('http:', location.protocol);
                    superZoom.prepareFromDocument(link, redirUrl, getSrc);
                }
            }
            var src = getSrc(doc);
            if (src) {
                if (Array.isArray(src)) {
                    link.data().superZoomGallerySrc = src;
                    link.data().superZoomGalleryIndex = 0;
                    link.data().superZoomSrc = src[0];
                } else {
                    link.data().superZoomSrc = [src];
                }
                link.addClass('superZoomLink');
                superZoom.displayPicFromElement(link);
            }
        });
    }
};

superZoom.loadSuperZoom();
